# NOVA AI VIDEO AGENT ULTRA — source archive

An AI creative-director web app: describe a film, get an enhanced prompt, a shot-by-shot
storyboard, automatic model routing and a real generation job. Express API + vanilla-JS SPA +
PostgreSQL, with a built-in ffmpeg storyboard renderer.

## Run it

Requires Docker with Compose.

```bash
docker compose -f docker-compose.base44.yml up -d --build
```

Open http://localhost:3000. The first account you register becomes the administrator.

## AI providers (optional)

The app works with no keys: the router falls back to the built-in local storyboard renderer and
produces a real MP4. To unlock Google Veo / Imagen, Runway or Kling, add keys either as
`GEMINI_API_KEY`, `RUNWAY_API_KEY`, `KLING_ACCESS_KEY` + `KLING_SECRET_KEY` in the environment, or
from Admin → Providers inside the app (stored encrypted with `APP_SECRET`).

## Layout

- `nova/server/` — API, job worker, director engine, provider adapters, local renderer
- `nova/public/` — SPA (hash routing), bilingual EN/AR UI
- `nova/Dockerfile` — runtime image with ffmpeg and Arabic fonts
- `docker-compose.base44.yml` — web + Postgres dev stack (source bind-mounted, live reload)
- `AGENTS.md` — notes for working in the code
